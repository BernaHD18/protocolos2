
#include <stdio.h>
#include <stdlib.h>
#include "Slip.h"

const BYTE Slip::END = 0xC0; // 192
const BYTE Slip::ESC = 0xDB; // 219
const BYTE Slip::DC = 0xDC;  // 220
const BYTE Slip::DD = 0xDD;  // 221

Slip::Slip(){}
void Slip::writeSlip(int port, BYTE* frame, int n){
	if(n>0) {
		serial.writePort(port,(BYTE*)(&END),1);
		for(int i=0; i<n; i++)
			if(frame[i]==END) {
				serial.writePort(port,(BYTE*)(&ESC),1);
				serial.writePort(port,(BYTE*)(&DC),1);
			} else if(frame[i]==ESC) {
				serial.writePort(port,(BYTE*)(&ESC),1);
				serial.writePort(port,(BYTE*)(&DD),1);
			} else
				serial.writePort(port,frame+i,1);
		serial.writePort(port,(BYTE*)(&END),1);
	}
}

int Slip::readSlip(int port, BYTE* frame, int timeOut){
	BYTE byte=0;
	int n=0;
	do {
        n = serial.readPort(port, &byte, 1, timeOut);
		if(n==0)return 0; //ocurre un timeOut
    } while(byte!=END);
	int i=0;
	do {
		n = serial.readPort(port, &byte, 1, timeOut);
		if(n==0)return 0; //ocurre un timeOut
		if(byte==ESC) {
			n = serial.readPort(port, &byte, 1, timeOut);
			if(n==0)return 0; //ocurre un timeOut
			if(byte==DC)
				frame[i]=END;
			if(byte==DD)
				frame[i]=ESC;
		}else 
			if(byte!=END)
				frame[i]=byte;			
		i++;
	} while(byte!=END);
	return i-1;
}
