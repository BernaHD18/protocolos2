#include <stdio.h>
#include <stdlib.h>
#include "Cola.h"
 
// Constructor de la clase Cola
Cola::Cola() {
    crearCola((Cabecera&)buffer);
}
// Destructor de la clase Cola
Cola::~Cola(){
    anula((Cabecera&)buffer);
}
// METODOS PUBLICOS
BYTE Cola::readByte(){
    while(vacia(buffer));
    BYTE byte = frente(buffer);
    quitarDeCola((Cabecera&)buffer);
    return byte;
}
bool Cola::readByte(BYTE & byte, int timeOut){
    while(vacia(buffer));
    byte = frente(buffer);
    quitarDeCola((Cabecera&)buffer);
    return true;
}
void Cola::writeByte(BYTE byte){
    ponerEnCola(byte,(Cabecera&)buffer);
}
// METODOS PRIVADOS
//implementaciones del TDA
void Cola::crearCola(Cabecera &c){
    c.ant = new tipoCelda;
	c.ant->next = NULL;
	c.post = c.ant;
}
void Cola::anula(Cabecera &c){
    while(!vacia(c))
        quitarDeCola(c);
}

bool Cola::vacia(Cabecera c){
    return c.ant == c.post;
}

tipoElemento Cola::frente(Cabecera c){
	if(vacia(c)){	
		printf("La cola esta vacia");
   		return(0);
	}
	else
   		return c.ant->next->elemento;
}

void Cola::ponerEnCola(tipoElemento x, Cabecera &c){	
	c.post->next = new tipoCelda;
	c.post = c.post->next;
	c.post->elemento = x;
	c.post->next = NULL;
}

void Cola::quitarDeCola(Cabecera &c){	
	if(vacia(c))
		printf("La cola esta vacia");
	else{
        tipoCelda* aux;
        aux = c.ant;
   		c.ant = c.ant->next;
   		aux->next=NULL;
   		delete aux;
    }
}