#ifndef PAQUETE_H_
#define PAQUETE_H_

#include <stdio.h>
#include <stdlib.h>

#define BYTE unsigned char

class paquete {
public:
    paquete();
    static int lCabecera;
    int cmd;
    int l;
    int cksm;
    int op;
    unsigned short int pnum;
    BYTE data[20];
    BYTE frame[25];

    void empaqueta();
    void desempaqueta();
    int size();
};

#endif /* PAQUETE_H_ */
