#include <stdio.h>
#include <stdlib.h>
#include "Ethernet.h"

Ethernet::Ethernet(){
}

 // 4b    4b   12b   4b   2B    15B
 // CMD | L  | SC  | OP | NP | DATA   
void Ethernet::empaqueta(){
	for(int i=0;i<6;i++){
		frame[i]=destino[i];
		frame[6+i]=origen[i];
	}
	frame[12]=largo & 0xFF;
	frame[13]=(largo>>8) & 0xFF;
	for(int i=0;i<largo;i++)
		frame[14+i]=data[i];
	int fcs = 0; //se debe calcular el FCS
	for(int i=0;i<4;i++)
		frame[largo+14+i]=(fcs>>(8*i)) & 0xFF;
}
int Ethernet::size(){
    return largo+L_HEADER;
}

bool Ethernet::desempaqueta(){
	largo = frame[12] | (frame[13] << 8);
	fcs = 0;
	for(int i=0;i<4;i++)
        fcs = fcs | (frame[largo+14+i]<<(8*i));
    for(int i=0;i<6;i++){
        destino[i]=frame[i];
        origen[i]=frame[6+i];
    }
    for(int i=0;i<largo;i++)
        data[i]=frame[14+i];
    int scAux = 0; //se debe calcular el FCS
    if(scAux == fcs)
    	return true;
	else
		return false;
}
