#ifndef COLA_H_
#define COLA_H_

#include <stdio.h>
#include <stdlib.h>

#define BYTE unsigned char
#define tipoElemento BYTE

class Cola {
private:
    //Estructuras del TDA
    struct tipoCelda{	
        tipoElemento elemento;
        tipoCelda *next;
    };
    struct Cabecera{	
        tipoCelda *ant,*post;
    };
    volatile Cabecera buffer;
    //prototipos
    void error(char *texto);
    void anula(Cabecera &c);
    bool vacia(Cabecera c);
    tipoElemento frente(Cabecera c);
    void ponerEnCola(tipoElemento x, Cabecera &c);
    void quitarDeCola(Cabecera &c);
    void crearCola(Cabecera &c);

public:
    // Constructor y Destructor
    Cola();   // Constructor que inicializa la cabecera
    ~Cola();  // Destructor que elimina todos los elementos de la cola
    bool readByte(BYTE & byte, int timeOut);// función NO bloqueante
    BYTE readByte();                        // función bloqueante
    void writeByte(BYTE byte);
};
#endif /* COLA_H_ */