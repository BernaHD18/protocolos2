#include <stdio.h>
#include <stdlib.h>
#include "Paquete.h"

int paquete::lCabecera=5;


paquete::paquete(){
	}

void paquete::empaqueta() {
    frame[0] = (cmd & 0x3F);
    frame[0] = frame[0] | (l & 0x03) << 6;
    frame[1] = (l & 0x1C) >> 2;
    frame[1] = frame[1] | (op & 0x1F) << 3;
    frame[2] = pnum & 0xFF;
    frame[3] = (pnum << 8) & 0xFF;
    for (int i = 0; i < l; i++) {
        frame[4 + i] = data[i];
    }
    frame[4 + l] = (cksm & 0xFF);
}

void paquete::desempaqueta() {
    cmd = (frame[0] & 0x3F);
    l = (frame[0] >> 6) & 0x03;
    l = l | (frame[1] & 0x07) << 2;
    op = (frame[1] & 0xF8) >> 3;
    pnum = frame[2] & 0xFF;
    pnum = pnum | (frame[3] & 0xFF) << 8;
    for (int i = 0; i < l; i++) {
        data[i] = frame[4 + i];
    }
    cksm = frame[4 + l] & 0xFF;
}

int paquete::size() {
    return l + lCabecera;
}

