#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <climits>
#include "libs/Paquete.h"
#include "libs/Cola.h"
#include "libs/Serial.h"
#include "libs/Ethernet.h"
#include "libs/Slip.h"

#define BYTE unsigned char
#define HELP "-h"
#define TTL 5
#define NUM_NODES 6
#define CMD_CONFIRM 2

const char* nodeMAC[NUM_NODES] = {
        "192161",
        "192162",
        "192163",
        "192164",
        "192165",
        "192166"
};

struct RoutingTableEntry {
    int originNode;
    int ttl;
    int finalPort;
};

Serial serial;
Slip slip;

void clearBuffer(BYTE* buffer, int size) {
    memset(buffer, 0, size);
}

void showMenu() {
    printf("\nMenu:\n");
    printf("1. Enviar mensaje hacia un nodo\n");
    printf("2. Recibir mensaje\n");
    printf("3. Salir\n");
    printf("Seleccione una opción: ");
}

void showNodes(int nodeNum) {
    printf("\nNodos disponibles:\n");
    for (int i = 0; i < NUM_NODES; i++) {
        if (i != nodeNum - 1) {
            printf("%d. Nodo %d (MAC: %s)\n", i + 1, i + 1, nodeMAC[i]);
        }
    }
    printf("Seleccione un nodo: ");
}

int main (int argc, char *argv[]) {
    if (argc == 4) {
        int nodeNum = *argv[3] - '0';
        printf("\nNodo #%d: ONLINE", nodeNum);
        printf("\nDirección propia: %s", nodeMAC[nodeNum-1]);
        printf("\n-----------------\n");

        int port = serial.openPort(argv[1], 9600);
        int port2 = serial.openPort(argv[2], 9600);
        int in = fileno(stdin);

        RoutingTableEntry routingTable[NUM_NODES];
        for (int i = 0; i < NUM_NODES; i++) {
            routingTable[i].originNode = -1;
            routingTable[i].ttl = INT_MAX;
            routingTable[i].finalPort = -1;
        }

        BYTE entrada[20];
        paquete recvPKG;
        paquete sendPKG;
        Ethernet ethSend;
        Ethernet ethRecv;
        BYTE buffer[ethSend.SIZE_FRAME];
        BYTE buffer2[ethSend.SIZE_FRAME];

        printf("\nGenerando tabla de ruteo... ");
        int broadcastCount = 0;
        int sendCount = 0;
        bool broadcastSent = false;

        while (broadcastCount < NUM_NODES) {
            clearBuffer(buffer, ethSend.SIZE_FRAME);
            clearBuffer(buffer2, ethSend.SIZE_FRAME);

            int izq = slip.readSlip(port, buffer, 3000);
            int der = slip.readSlip(port2, buffer2, 3000);

            if (!broadcastSent) {
                sendPKG.l = 1; sendPKG.cmd = 1; sendPKG.pnum = nodeNum;
                sendPKG.op = TTL;
                sendPKG.empaqueta();
                for (int i = 0; i < sendPKG.size(); i++) {
                    ethSend.data[i] = sendPKG.frame[i];
                }
                ethSend.largo = sendPKG.size();
                memcpy(ethSend.origen, nodeMAC[nodeNum-1], 6);
                ethSend.empaqueta();

                if (sendCount < NUM_NODES) {
                    if (izq == 0) {
                        for (int i = 0; i < ethSend.size(); i++) {
                            buffer[i] = ethSend.frame[i];
                        }
                        slip.writeSlip(port, buffer, ethSend.size());
                    }
                    if (der == 0) {
                        for (int i = 0; i < ethSend.size(); i++) {
                            buffer2[i] = ethSend.frame[i];
                        }
                        slip.writeSlip(port2, buffer2, ethSend.size());
                    }
                    sendCount++;
                } else {
                    broadcastSent = true;
                }
            }

            if (izq > 0) {
                for (int i = 0; i < izq; i++) {
                    ethRecv.frame[i] = buffer[i];
                }
                ethRecv.desempaqueta();
                for (int i = 0; i < ethRecv.largo; i++) {
                    recvPKG.frame[i] = ethRecv.data[i];
                }
                recvPKG.desempaqueta();
                if (recvPKG.cmd == 1) {
                    int senderNode = recvPKG.pnum;
                    int ttl = recvPKG.op;
                    if (routingTable[senderNode].ttl > ttl) {
                        routingTable[senderNode].originNode = senderNode;
                        routingTable[senderNode].ttl = ttl;
                        routingTable[senderNode].finalPort = 1;
                    }
                    if (ttl > 1) {
                        recvPKG.op = ttl - 1;
                        recvPKG.empaqueta();
                        for (int i = 0; i < recvPKG.size(); i++) {
                            ethSend.data[i] = recvPKG.frame[i];
                        }
                        ethSend.largo = recvPKG.size();
                        ethSend.empaqueta();
                        slip.writeSlip(port2, ethSend.frame, ethSend.size());

                        // Enviar confirmación
                        paquete confirmPKG;
                        confirmPKG.l = 1; confirmPKG.cmd = CMD_CONFIRM; confirmPKG.pnum = nodeNum;
                        confirmPKG.op = 0;
                        confirmPKG.empaqueta();
                        for (int i = 0; i < confirmPKG.size(); i++) {
                            ethSend.data[i] = confirmPKG.frame[i];
                        }
                        ethSend.largo = confirmPKG.size();
                        ethSend.empaqueta();
                        slip.writeSlip(port, ethSend.frame, ethSend.size());
                    }
                }
            }

            if (der > 0) {
                for (int i = 0; i < der; i++) {
                    ethRecv.frame[i] = buffer2[i];
                }
                ethRecv.desempaqueta();
                for (int i = 0; i < ethRecv.largo; i++) {
                    recvPKG.frame[i] = ethRecv.data[i];
                }
                recvPKG.desempaqueta();
                if (recvPKG.cmd == 1) {
                    int senderNode = recvPKG.pnum;
                    int ttl = recvPKG.op;
                    if (routingTable[senderNode].ttl > ttl) {
                        routingTable[senderNode].originNode = senderNode;
                        routingTable[senderNode].ttl = ttl;
                        routingTable[senderNode].finalPort = 2;
                    }
                    if (ttl > 1) {
                        recvPKG.op = ttl - 1;
                        recvPKG.empaqueta();
                        for (int i = 0; i < recvPKG.size(); i++) {
                            ethSend.data[i] = recvPKG.frame[i];
                        }
                        ethSend.largo = recvPKG.size();
                        ethSend.empaqueta();
                        slip.writeSlip(port, ethSend.frame, ethSend.size());

                        // Enviar confirmación
                        paquete confirmPKG;
                        confirmPKG.l = 1; confirmPKG.cmd = CMD_CONFIRM; confirmPKG.pnum = nodeNum;
                        confirmPKG.op = 0;
                        confirmPKG.empaqueta();
                        for (int i = 0; i < confirmPKG.size(); i++) {
                            ethSend.data[i] = confirmPKG.frame[i];
                        }
                        ethSend.largo = confirmPKG.size();
                        ethSend.empaqueta();
                        slip.writeSlip(port2, ethSend.frame, ethSend.size());
                    }
                }
            }
            broadcastCount++;
        }

        printf("\nTabla de ruteo generada:\n");
        for (int i = 0; i < NUM_NODES; i++) {
            if (routingTable[i].originNode != -1) {
                printf("\nNodo %d: TTL=%d, Puerto=%d", i, routingTable[i].ttl, routingTable[i].finalPort);
            }
        }

        while (true) {
            showMenu();
            int option;
            scanf("%d", &option);

            if (option == 3) {
                printf("Saliendo del programa...\n");
                break;
            } else if (option == 1) {
                showNodes(nodeNum);
                int targetNode;
                scanf("%d", &targetNode);
                targetNode--; // Ajustar índice

                printf("Ingrese el mensaje a enviar: ");
                scanf("%s", entrada);

                int msgLength = strlen((char*)entrada);
                for (int i = 0; i < msgLength; i++) {
                    sendPKG.data[i] = entrada[i];
                }
                sendPKG.l = msgLength;
                sendPKG.cmd = 3;
                sendPKG.pnum = targetNode + 1;
                sendPKG.op = TTL;
                sendPKG.empaqueta();

                ethSend.largo = sendPKG.size();
                for (int i = 0; i < sendPKG.size(); i++) {
                    ethSend.data[i] = sendPKG.frame[i];
                }
                memcpy(ethSend.destino, nodeMAC[targetNode], 6);
                ethSend.empaqueta();

                for (int i = 0; i < ethSend.size(); i++) {
                    buffer[i] = ethSend.frame[i];
                }
                slip.writeSlip(port, buffer, ethSend.size());
                printf("Mensaje enviado al nodo %d\n", targetNode + 1);
            } else if (option == 2) {
                printf("Esperando mensajes...\n");
                bool messageReceived = false;
                while (!messageReceived) {
                    int y = slip.readSlip(port, buffer, 3000);
                    int x = slip.readSlip(port2, buffer2, 3000);
                    if (x > 0) {
                        buffer2[x] = '\0';
                        for (int n = 0; n < x; n++) {
                            ethRecv.frame[n] = buffer2[n];
                        }
                        if (ethRecv.desempaqueta()) {
                            for (int n = 0; n < ethRecv.largo; n++) {
                                recvPKG.frame[n] = ethRecv.data[n];
                            }
                            recvPKG.desempaqueta();
                            if (memcmp(ethRecv.destino, nodeMAC[nodeNum-1], 6) == 0) {
                                printf("Mensaje recibido: %s\n", recvPKG.data);
                                messageReceived = true;
                            } else {
                                // Reenviar el mensaje al puerto correspondiente
                                int finalPort = routingTable[recvPKG.pnum - 1].finalPort;
                                if (finalPort == 1) {
                                    slip.writeSlip(port, ethRecv.frame, ethRecv.size());
                                } else if (finalPort == 2) {
                                    slip.writeSlip(port2, ethRecv.frame, ethRecv.size());
                                }
                            }
                        }
                    }
                    if (y > 0) {
                        buffer[y] = '\0';
                        for (int n = 0; n < y; n++) {
                            ethRecv.frame[n] = buffer[n];
                        }
                        if (ethRecv.desempaqueta()) {
                            for (int n = 0; n < ethRecv.largo; n++) {
                                recvPKG.frame[n] = ethRecv.data[n];
                            }
                            recvPKG.desempaqueta();
                            if (memcmp(ethRecv.destino, nodeMAC[nodeNum-1], 6) == 0) {
                                printf("Mensaje recibido: %s\n", recvPKG.data);
                                messageReceived = true;
                            } else {
                                // Reenviar el mensaje al puerto correspondiente
                                int finalPort = routingTable[recvPKG.pnum - 1].finalPort;
                                if (finalPort == 1) {
                                    slip.writeSlip(port, ethRecv.frame, ethRecv.size());
                                } else if (finalPort == 2) {
                                    slip.writeSlip(port2, ethRecv.frame, ethRecv.size());
                                }
                            }
                        }
                    }
                }
            } else {
                printf("Opción no válida. Intente de nuevo.\n");
            }
        }

        printf("Done!!\n");

    } else if (argc == 2 && strcmp(argv[1], HELP) == 0) {
        printf("MANUAL DE USUARIO:\n");
        printf("-------------------\n");
        printf(" Es necesario levantar previamente la red usando VirtualSocket. Llame el manual usando './virtualSocket -h'\n");
        printf("\t Modo de Uso:\n");
        printf("\t\t1-.\t./main\n");
        printf("\t\t2-.\t./main puerto1 puerto2\n\n");
        printf("\t Ejemplo:\n");
        printf("\t\t2-.\t./main tmp/p1 tmp/p2\n");
    } else
        printf("Error de argumentos!\n\t Use: ./main -h\n");
    return 0;
}